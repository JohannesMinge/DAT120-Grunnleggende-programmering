# -*- coding: utf-8 -*-
"""
Created on Mon Aug 30 11:34:12 2021

@author: Erlend Tøssebro
"""

def enkel_funksjon():
    print("Skriver ut testetekst")
    print("En linje til i blokken")
    

print("Test")
enkel_funksjon()
print("Prøver en gang til")
enkel_funksjon()
