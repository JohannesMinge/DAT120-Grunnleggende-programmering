# -*- coding: utf-8 -*-
"""
Created on Thu Aug 26 09:13:47 2021

@author: Erlend Tøssebro
"""

STORRELSE = 60

import turtle

turtle.setup(500,800,1200,250)
turtle.forward(STORRELSE)
turtle.right(90)
turtle.forward(STORRELSE)
turtle.right(90)
turtle.forward(STORRELSE)
turtle.right(90)
turtle.forward(STORRELSE)
turtle.right(90)
turtle.done()

