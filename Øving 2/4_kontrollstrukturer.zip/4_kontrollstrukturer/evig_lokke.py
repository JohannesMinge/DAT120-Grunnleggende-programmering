# -*- coding: utf-8 -*-
"""
Created on Tue Aug 24 15:43:36 2021

@author: Erlend Tøssebro
"""

tall = 5
while tall != 10:
    print(tall)
    tall = tall + 2
print(tall)
