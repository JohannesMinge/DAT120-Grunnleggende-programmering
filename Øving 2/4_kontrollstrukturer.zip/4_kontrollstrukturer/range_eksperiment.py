# -*- coding: utf-8 -*-
"""
Created on Wed Aug 25 08:55:53 2021

@author: Erlend Tøssebro
"""

for i in range(10, 0, -1):
    print(i)
print("Etter for-løkka er ferdig")
