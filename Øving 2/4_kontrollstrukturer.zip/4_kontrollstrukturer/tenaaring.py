# -*- coding: utf-8 -*-
"""
Created on Tue Aug 24 11:36:00 2021

@author: Erlend Tøssebro
"""

tall_streng = input("Skriv inn en alder: ")
alder = int(tall_streng)
if alder >= 13 and alder < 18:
    print("Personen er tenåring")
else:
    print("Personen er ikke tenåring")
