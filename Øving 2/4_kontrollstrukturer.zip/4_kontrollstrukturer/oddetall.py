# -*- coding: utf-8 -*-
"""
Created on Tue Aug 24 14:30:14 2021

@author: Erlend Tøssebro
"""

tall_streng = input("Skriv inn et tall: ")
tall = int(tall_streng)
if not (tall % 2) == 0:
    print("Tallet er et oddetall")
