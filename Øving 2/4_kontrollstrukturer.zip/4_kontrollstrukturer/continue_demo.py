# -*- coding: utf-8 -*-
"""
Created on Wed Aug 25 11:01:50 2021

@author: Erlend Tøssebro
"""


for i in range(1, 21):
    if i==13:
        continue
    print(i)
