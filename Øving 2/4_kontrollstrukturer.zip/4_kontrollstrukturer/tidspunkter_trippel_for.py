# -*- coding: utf-8 -*-
"""
Created on Wed Aug 25 09:53:02 2021

@author: Erlend Tøssebro
"""


for time in range(24):
    for minutt in range(60):
        for sekund in range(60):
            print(time, ": ", minutt, ": ", sekund)
